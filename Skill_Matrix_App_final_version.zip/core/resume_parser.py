#core/resume_parser.py
import logging
import json
import re
from docx import Document
from utils.file_utils import extract_text_from_file
from core.llama_runner import run_llama_prompt
import time # Added import

logger = logging.getLogger(__name__)

MAX_RESUME_CONTEXT_CHARS = 16000 # Roughly ~4000 tokens. Adjust as needed based on model and performance.

def parse_resume_to_structured_data(file_path: str) -> dict:
    start_total_time = time.perf_counter() # Start timer for function
    logger.info("Attempting to parse resume file '%s' to structured data.", file_path)
    resume_raw_text = ""
    try:
        start_extract_time = time.perf_counter()
        resume_raw_text = extract_text_from_file(file_path)
        end_extract_time = time.perf_counter()
        logger.info("Successfully extracted raw text from resume. Length: %d (Duration: %.4f s)", len(resume_raw_text), end_extract_time - start_extract_time)
        if not resume_raw_text:
            logger.error("No text extracted from resume file: %s", file_path)
            return {"error": "Could not extract text from the resume file."}
    except Exception as e:
        logger.error("Failed to extract text from resume file '%s': %s", file_path, e, exc_info=True)
        return {"error": f"Failed to read resume file: {e}"}

    truncated_resume_text = resume_raw_text
    if len(resume_raw_text) > MAX_RESUME_CONTEXT_CHARS:
        truncated_resume_text = resume_raw_text[:MAX_RESUME_CONTEXT_CHARS]
        logger.warning(f"Resume text truncated from {len(resume_raw_text)} to {MAX_RESUME_CONTEXT_CHARS} characters for LLM context. Information at the end of the resume might be missed.")
        truncated_resume_text += "\n\n[RESUME TEXT TRUNCATED DUE TO LENGTH - IMPORTANT: INFORMATION AT THE END MAY BE MISSING]"

    # --- NEW: Programmatic Pre-Extraction of Name ---
    extracted_name = ""
    # Only send a very small portion to the LLM for name extraction
    first_few_lines = "\n".join(resume_raw_text.splitlines()[:5])

    name_extraction_prompt = f"""
    Extract ONLY the full name from the following text. The name is typically found at the very beginning or in the most prominent header section.
    If no name is clearly identifiable, respond with "[NAME_NOT_FOUND]".
    Text:
    ---
    {first_few_lines}
    ---
    Full Name:
    """
    
    start_name_llm_time = time.perf_counter()
    # Use very low temperature (0.0 for deterministic) and small max_new_tokens for fast, precise name extraction
    name_llm_response = run_llama_prompt(name_extraction_prompt, context=first_few_lines, max_new_tokens=50, temperature=0.0)
    end_name_llm_time = time.perf_counter()
    logger.info("LLM responded for name extraction (Duration: %.4f s). Response: '%s'", end_name_llm_time - start_name_llm_time, name_llm_response)

    if name_llm_response and name_llm_response.strip().lower() != "[name_not_found]":
        extracted_name = name_llm_response.strip()
    # --- END NEW: Programmatic Pre-Extraction ---


    # Main parsing prompt now uses the extracted_name directly in the schema
    prompt = f"""
    You are an expert resume parser assistant. Your primary goal is to extract detailed information from the provided resume text.
    
    You MUST output the extracted data as a single, valid JSON object. Do not include any conversational text, explanations, or markdown outside the JSON block.
    If a field is not found or is not applicable in the resume, its corresponding value in the JSON should be an empty string ("") for single values, or an empty list ([]) for lists.
    Ensure all other extracted data is directly and accurately from the resume.

    Strictly adhere to the following JSON schema for your output.
    ```json
    {{
      "full_name": "{extracted_name}",  # INJECTING THE PRE-EXTRACTED NAME HERE
      "email": "string",
      "phone_number": "string",
      "linkedin_profile": "string",
      "github_profile": "string",
      "personal_website": "string",
      "professional_summary": "string",
      "skills": ["string"],
      "technologies": ["string"],
      "core_competencies": ["string"],
      "experience": [
        {{
          "title": "string",
          "company": "string",
          "location": "string",
          "duration": "string",
          "responsibilities": ["string"]
        }}
      ],
      "education": [
        {{
          "degree": "string",
          "university": "string",
          "location": "string",
          "year_obtained": "string"
        }}
      ],
      "awards": ["string"],
      "certifications": ["string"],
      "languages": ["string"]
    }}
    ```

    Resume Text to Parse:
    ---
    {truncated_resume_text}
    ---

    Your JSON output:
    ```json
    """
    
    try:
        # Use a slightly higher temperature for the rest of the parsing, but still controlled
        start_llm_time = time.perf_counter()
        llm_response = run_llama_prompt(prompt, context=truncated_resume_text, max_new_tokens=2500, temperature=0.2)
        end_llm_time = time.perf_counter()
        logger.info("LLM responded for main resume data extraction (Duration: %.4f s).", end_llm_time - start_llm_time)
        
        start_json_parse_time = time.perf_counter()
        json_match = re.search(r'```json\n(.*)\n```', llm_response, re.DOTALL)
        if json_match:
            json_str = json_match.group(1).strip()
        else:
            json_str = llm_response.strip()

        try:
            resume_data = json.loads(json_str)
            # --- CRITICAL: Override the name field with the pre-extracted name (final safeguard) ---
            if extracted_name:
                resume_data["full_name"] = extracted_name
                logger.info("Overriding final 'full_name' with pre-extracted name: '%s'", extracted_name)
            # --- End Override ---

            end_json_parse_time = time.perf_counter()
            logger.info("Successfully parsed structured resume data from LLM response (Duration: %.4f s).", end_json_parse_time - start_json_parse_time)
            
            end_total_time = time.perf_counter()
            logger.info("Total parse_resume_to_structured_data completed (Total Duration: %.4f s).", end_total_time - start_total_time)
            return resume_data
        except json.JSONDecodeError as e:
            logger.error(f"JSON Decode Error during resume data extraction: {e}")
            logger.error(f"Malformed JSON from LLM:\n{json_str}")
            return {"error": f"Failed to parse structured resume data from LLM: {e}. Raw LLM output: {json_str[:500]}..."}
    except Exception as e:
        logger.error(f"Error calling LLM for resume data extraction: {e}", exc_info=True)
        return {"error": f"LLM processing error during resume data extraction: {e}"}